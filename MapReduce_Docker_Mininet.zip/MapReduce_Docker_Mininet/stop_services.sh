# !/bin/sh

# Purpose: Script to stop the services
#
docker service rm MyMR_Master MyMR_Map MyMR_Reduce

